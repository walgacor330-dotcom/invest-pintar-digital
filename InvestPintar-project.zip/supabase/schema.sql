-- InvestPintar starter schema for Supabase.
-- This schema does NOT activate real payment processing or investment custody.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.ledger_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  amount bigint not null,
  entry_type text not null check (entry_type in ('deposit','withdrawal','investment','investment_return','adjustment')),
  status text not null default 'pending' check (status in ('pending','confirmed','rejected')),
  reference text unique,
  note text,
  created_at timestamptz not null default now()
);

create table if not exists public.payment_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  amount bigint not null check (amount >= 10000),
  provider text not null default 'qris',
  provider_reference text unique,
  status text not null default 'pending' check (status in ('pending','paid','expired','rejected')),
  created_at timestamptz not null default now(),
  paid_at timestamptz
);

create table if not exists public.withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  amount bigint not null check (amount >= 10000),
  bank_name text not null,
  account_name text not null,
  account_number_encrypted text,
  status text not null default 'pending' check (status in ('pending','processing','paid','rejected')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

create table if not exists public.investment_positions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  principal bigint not null check (principal in (50000,100000,200000,500000,1000000)),
  units numeric,
  purchase_price numeric,
  status text not null default 'simulation' check (status in ('simulation','active','sold','cancelled')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.ledger_entries enable row level security;
alter table public.payment_requests enable row level security;
alter table public.withdrawal_requests enable row level security;
alter table public.investment_positions enable row level security;

create policy "profiles read own" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "profiles update own safe fields" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "ledger read own" on public.ledger_entries for select to authenticated using (auth.uid() = user_id);
create policy "payment requests read own" on public.payment_requests for select to authenticated using (auth.uid() = user_id);
create policy "payment requests create own" on public.payment_requests for insert to authenticated with check (auth.uid() = user_id);
create policy "withdrawals read own" on public.withdrawal_requests for select to authenticated using (auth.uid() = user_id);
create policy "withdrawals create own" on public.withdrawal_requests for insert to authenticated with check (auth.uid() = user_id);
create policy "positions read own" on public.investment_positions for select to authenticated using (auth.uid() = user_id);

create or replace function public.create_profile_for_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email) values (new.id, new.email);
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.create_profile_for_new_user();

-- IMPORTANT:
-- Do not let browser clients update balances, approve deposits, or approve withdrawals.
-- Implement these actions in a trusted server/Edge Function after verifying payment provider webhooks.
-- Never expose SUPABASE_SERVICE_ROLE_KEY in frontend code.
