# InvestPintar — starter project

A responsive dark/copper UI for InvestPintar with login/register, dashboard, five nominal packages, deposit request flow, withdrawal request form, transaction history, and a demo admin screen.

## Honest scope / important limitations

This project is runnable and testable. By default it is **local demo mode**:
- Accounts and demo data are stored in this browser's `localStorage`.
- A newly registered demo account starts with a virtual balance of Rp1,000,000.
- QRIS deposit requests stay pending; uploading a QR image does not verify payment or credit a balance.
- Withdrawals in demo mode only record a request; no money is sent.
- Packages are simulations and do not buy copper or promise returns.
- The admin screen is a demo, not a production-grade privileged control plane.

Do not accept money or represent this demo as a live investment service. Real-money operation needs a compliant business model, required Indonesian licenses, a payment provider agreement, server-side webhook verification, ledger posting, fraud controls, and a secure admin backend.

## Run locally

Requirements: Node.js 20+.

```bash
npm install
npm run dev
```

Open the URL printed by Vite, usually `http://localhost:5173`.

Build check:

```bash
npm run build
npm run preview
```

## Optional Supabase setup (authentication starter)

1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. Copy `.env.example` to `.env`.
4. Fill in `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` from Project Settings → API.
5. Run `npm install` then `npm run dev`.

This starter only includes the initial Supabase auth/profile connection. The UI deliberately does not pretend real-money ledger, deposits, withdrawals, or investments are live when no trusted backend/payment provider has been implemented. Review and tighten the SQL policies and add server-side Edge Functions before production.

## Publish publicly with Vercel

1. Create a GitHub repository and upload the project files.
2. Sign in at https://vercel.com/ and import the repository.
3. Framework preset: **Vite**. Build command: `npm run build`. Output directory: `dist`.
4. If using Supabase auth, add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in Vercel → Project → Settings → Environment Variables.
5. Deploy. Vercel will give you a public `*.vercel.app` URL.
6. Test on mobile, test signup/login, inspect console/build logs, and configure your own domain if desired.

You can also use Netlify with build command `npm run build` and publish directory `dist`.

## Before real-money launch

- Obtain legal advice on the actual product and all required Indonesian licenses/registrations.
- Use a payment provider that explicitly supports your business model and QRIS merchant arrangement.
- Use dynamic QRIS/payment intents and verify signed provider webhooks on a server/Edge Function. Never trust screenshots or a client-side “paid” button.
- Ensure payment references are idempotent, reconcile provider settlements, and create ledger entries only from trusted server code.
- Build secure withdrawal processing with identity checks, approval rules, bank-provider integration, limits, and audit trails.
- Keep service-role keys and payment secrets server-side only.
- Have an independent security review before accepting public users' funds.
